import java.util.Scanner;
public class DigitReassembly {
	static long[] array = new long[5];
	//OLD main method
	/*public static void main(String[] args) {
		Scanner scan = new Scanner (System.in);
		System.out.println("Enter the test cases:");
		while(scan.hasNextLine()) {
			String line = scan.nextLine();
			//splits the line into an array
			String[] arr = line.split(" ");
			//the first part of the array is the number
			String number = arr[0];
			//the second part is the key
			int key = Integer.parseInt(arr[1]);
			//prints out the sum using the getSum
			System.out.println(getSum(number, key));
		}
	}*/
	
	//method to get the sum
	public static long getSum (String number, int key) {		//returns a long
		long answer = 0;
		for(int i=0; i<=number.length()-key; i++) {
			//creates each number using the substring method of the string
			String num = number.substring(i, i+key);
			//creates that string into a long
			long fin = Long.parseLong(num);
			//creates a sum
			answer += fin;
		}
		//returns the sum
		return answer;
	}
	
	//new main method
	public static void main(String[] args) {
		Scanner scan = new Scanner (System.in);
		System.out.println("Enter the test cases:");
		for(int i=0; i<array.length; i++) {
			String line = scan.nextLine();
			//splits the line into an array
			String[] arr = line.split(" ");
			//the first part of the array is the number
			String number = arr[0];
			//the second part is the key
			int key = Integer.parseInt(arr[1]);
			array[i] = getSum(number, key);
		}
		
		for(int i=0; i<array.length; i++) {
			System.out.println(array[i]);
		}
	}
}
