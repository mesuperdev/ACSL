import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
public class StringComparison {
	public ArrayList<String> alpha;
	public ArrayList<String> beta;
	public ArrayList<String> gamma;

	public ArrayList getOne(String s1, String s2) {
		alpha = new ArrayList<String>();
		for (int i=0; i<s1.length(); i++) {
			char c = s1.charAt(i);
			String s = String.valueOf(c);
			if(s2.contains(s)) {
				if(s.indexOf(c) == s2.length() - 1) {
					alpha.add(s);
					s2 = "";
				}
				else {
					alpha.add(s);
					s2 = s2.substring(s2.indexOf(s)+1, s2.length());
				}
			}
		}
		return alpha;
	}
	
	public ArrayList getTwo (String s1, String s2) {
		beta = new ArrayList<String>();
		for (int i=0; i<s2.length(); i++) {
			char c = s2.charAt(i);
			String s = String.valueOf(c);
			if(s1.contains(s)){
				if(s.indexOf(c) == s1.length() - 1) {
					beta.add(s);
					s1 = "";
				}
				else {
					beta.add(s);
					s1 = s1.substring(s1.indexOf(s)+1, s1.length());
				}
			}
		}
		return beta;
	}
	
	public ArrayList getCommon (ArrayList<String> a1, ArrayList<String> a2, ArrayList<String> a3, ArrayList<String> a4) {
		gamma = new ArrayList<String>();
		for(int i=0; i<a1.size(); i++) {
			if(a2.contains(a1.get(i)) && a3.contains(a1.get(i)) && a4.contains(a1.get(i)) && (!gamma.contains(a1.get(i)))) {
				gamma.add(a1.get(i));
				a1.remove(i);
			}
		}
		for(int i=0; i<a2.size(); i++) {
			if(a1.contains(a2.get(i)) && a3.contains(a2.get(i)) && a4.contains(a2.get(i)) && (!gamma.contains(a2.get(i)))) {
				gamma.add(a2.get(i));
				a2.remove(i);
			}
		}
		for(int i=0; i<a3.size(); i++) {
			if(a2.contains(a3.get(i)) && a1.contains(a3.get(i)) && a4.contains(a3.get(i)) && (!gamma.contains(a3.get(i)))) {
				gamma.add(a3.get(i));
				a3.remove(i);
			}
		}
		for(int i=0; i<a4.size(); i++) {
			if(a2.contains(a4.get(i)) && a3.contains(a4.get(i)) && a1.contains(a4.get(i)) && (!gamma.contains(a4.get(i)))) {
				gamma.add(a4.get(i));;
				a4.remove(i);
			}
		}
		return gamma;
	}
}
