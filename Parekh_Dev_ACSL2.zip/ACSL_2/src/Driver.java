import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/*To run the program, 
 * copy and paste the five 
 * lines of input*/


public class Driver {
	//static ArrayList<ArrayList> answer = new ArrayList<ArrayList>();
	static ArrayList[] bigArr = new ArrayList[5];
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		for(int j=0; j<5; j++) {
			String line = scan.nextLine();
			//splits the line into an array
			String[] arr = line.split(" ");
			String s1 = arr[0];
			String s2 = arr[1];
			String s1Reverse = "";
			String s2Reverse = "";
			for(int i=s1.length()-1; i>=0; i--) {
				s1Reverse+=s1.charAt(i);
			}
			for(int i=s2.length()-1; i>=0; i--) {
				s2Reverse+=s2.charAt(i);
			}
			StringComparison sc = new StringComparison();
			ArrayList<String> alpha = sc.getOne(s1, s2);
			ArrayList<String> beta = sc.getTwo(s1, s2);
			ArrayList<String> gamma = sc.getOne(s1Reverse, s2Reverse);
			ArrayList<String> delta = sc.getTwo(s1Reverse, s2Reverse);
			ArrayList answer = (sc.getCommon(alpha, beta, gamma, delta));
			Collections.sort(answer);
			bigArr[j] = answer;
		}
		for(int i=0; i<bigArr.length; i++) {
			for(int k=0; k<bigArr[i].size(); k++) {
				System.out.print(bigArr[i].get(k));
			}
			System.out.println();
		}
	}
}
